public class Lab extends Lesson {
}
