public class Coursework {
    private Component[] Components;
    private int Weight;

    public Component[] getComponents() {
        return Components;
    }

    public void setComponents(Component[] components) {
        Components = components;
    }

    public int getWeight() {
        return Weight;
    }

    public void setWeight(int weight) {
        Weight = weight;
    }
}
