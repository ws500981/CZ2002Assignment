public class Tutorial extends Lesson {
}
